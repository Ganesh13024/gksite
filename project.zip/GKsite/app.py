from flask import Flask, render_template , request
app = Flask(__name__)


@app.route('/')
def login():
    return render_template('login.html')

@app.route('/licence')
def licence_policy():
    return render_template('licence.html')

@app.route('/signup')
def sign_up():
    return render_template('signup.html')

database = {"admin@gmail.com":"ganesh"}

@app.route('/sign', methods=['POST','GET'])
def sign():
    if request.method == 'POST':
        name=request.form['mail']
        pwd=request.form['passw']
        database[name]="pwd"
        return render_template('success.html')

@app.route('/ain', methods=['POST'])
def main():
        name1=request.form['mailid']
        pwd=request.form['pass']
        if name1 not in database:
            return render_template('login.html',info='Invalid USER')
        else:
            if database[name1]!=pwd:
                return render_template('login.html',info='Invalid password')
            else:
                return render_template('ain.html')
if __name__ == '__main__':
    app.run(debug=True)